<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "protofolio_20246019";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql_about = "SELECT id, judul, deskripsi, sub_deskripsi FROM about_cards";
$result_about = $conn->query($sql_about);
?>

<section class="about-section" id="about">
    <h2 class="about-title">About</h2>

    <div class="about-content">
        <div class="about-text">
            <h1>About Me</h1>

            <div class="about-grid">
                <?php
                if ($result_about->num_rows > 0) {
                  while($row = $result_about->fetch_assoc()) {
                    echo '<div class="about-card">';
                    echo '  <h3>' . htmlspecialchars($row["judul"]) . '</h3>';
                    echo '  <p>' . htmlspecialchars($row["deskripsi"]) . '</p>';
                    
                    if (!empty($row["sub_deskripsi"])) {
                      echo '  <span>' . htmlspecialchars($row["sub_deskripsi"]) . '</span>';
                    }
                    
                    echo '</div>';
                  }
                } else {
                  echo "0 results";
                }
                ?>
            </div>
        </div>

        <div class="performance">
            <h2>Performance</h2>
            <p class="chart-subtitle">Technology Skills <span id="live-status" style="color: #16a34a; font-size: 0.85em;">● Live</span></p>

            <!-- Elemen Canvas untuk ChartJS -->
            <div class="line-chart chart-container">
                <canvas id="skillsChart" aria-label="Grafik tingkat kemampuan teknologi" role="img"></canvas>
            </div>
        </div>
    </div>
</section>

<?php
$conn->close();
?>

<!-- Script Chart.js dengan Real-Time Update -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('skillsChart').getContext('2d');

    // 1. Inisialisasi grafik kosong terlebih dahulu
    const skillsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Tingkat Kemampuan (%)',
                data: [],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                borderWidth: 2,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });

    // 2. Fungsi untuk mengambil data terbaru dari get_skills.php
    async function fetchRealtimeSkills() {
        try {
            const response = await fetch('get_skills.php');
            const data = await response.json();

            if (!data.error) {
                // Perbarui label dan nilai grafik jika ada perubahan
                skillsChart.data.labels = data.labels;
                skillsChart.data.datasets[0].data = data.values;
                skillsChart.update();
            }
        } catch (error) {
            console.error('Gagal mengambil data real-time:', error);
        }
    }

    // Panggil pertama kali saat halaman dimuat
    fetchRealtimeSkills();

    // Ulangi pengambilan data setiap 2 detik (2000 ms)
    setInterval(fetchRealtimeSkills, 2000);
</script>